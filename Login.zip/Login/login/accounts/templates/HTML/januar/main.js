const qs = (selector, all = false) => { 
    return all ? document.querySelectorAll(selector) : document.querySelector(selector)
}

const sections = qs('.section-second', true)
const timeline = qs('.timeline-second')
const line = qs('.line-second')
line.style.bottom = `calc(100% - 20px)`
let prevScrollY = window.scrollY
let up, down;
let full = false;
let set = 0;
const targetY = window.innerHeight * 0.8



const scrollHandler = (e) => { 
    const{
        scrollY
    } = window;
    up = scrollY < prevScrollY;
    down = !up;
    const timelineRect = timeline.getBoundingClientRect()
    const lineRect = line.getBoundingClientRect()

    const dist = targetY - timelineRect.top
    console.log(dist)

    if (down && !full){
        set = Math.max(set, dist);
            line.style.bottom = `calc(100% - ${set}px)`
    }

    if (dist > timeline.offsetHeight + 50 && !full){
        full = true
        line.style.bottom = `-80px`
    }

    sections.forEach(item => {
        const rect = item.getBoundingClientRect()

        if(rect.top + item.offsetHeight / 5 < targetY){
            item.classList.add('show-me')
        }
    });

    prevScrollY = window.scrollY
}

scrollHandler();
line.style.display = 'block'
window.addEventListener('scroll', scrollHandler)


// ----------------------------
// dropleft menu
const btns = document.querySelectorAll('.btn');
const dropMenus = document.querySelectorAll('.drop-menu');


btns.forEach(btn => {
    btn.addEventListener('click', () => {
        btns.forEach(btn => btn.classList.remove('active'));
        dropMenus.classList.remove('active');
        btns.classList.add('active');
        dropMenus.classList.add('active');
    })
})

const removeActive = () => {
    btns.forEach(btn => btn.classList.remove('active'));
    dropMenus.forEach(dropmenu => dropmenu.classList.remove('active'));
}

window.onclick = (e) => {
    if (!e.target.matches('.btn')) {
        removeActive()
    }
}