from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required

def indexView(request):
    return render(request,"home.html")

def dashboardView(request):
    return render(request, "dashboard.html")

def registerView(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("login_url")
    else:
        form = UserCreationForm()

    return render(request, "registration/register.html", {"form": form})

def janView(request):
    return render(request, "../accounts/templates/HTML/januar/januar.html")

def febView(request):
    return render(request, "../accounts/templates/HTML/februar/februar.html")

def marView(request):
    return render(request, "/HTML/marec/marce.html")

def aprView(request):
    return render(request, "/HTML/april/april.html")

def majView(request):
    return render(request, "/HTML/maj/maj.html")

def junView(request):
    return render(request, "dashboard.html")

def julView(request):
    return render(request, "dashboard.html")

def augView(request):
    return render(request, "dashboard.html")

def sepView(request):
    return render(request, "dashboard.html")

def oktView(request):
    return render(request, "dashboard.html")

def novView(request):
    return render(request, "dashboard.html")

def decView(request):
    return render(request, "dashboard.html")

